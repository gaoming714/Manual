rm -rf src
rm init.sh
rm build.sh
rm ohmyzsh.sh
rm -rf /home
rm clean.sh