sh src/install.sh

echo "run VIM, run :PlugInstall"